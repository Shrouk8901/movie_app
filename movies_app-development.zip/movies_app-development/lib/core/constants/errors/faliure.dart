class Failure {
  final String errorMessage;

  Failure(this.errorMessage);
}
